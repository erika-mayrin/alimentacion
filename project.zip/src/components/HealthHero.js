import React from 'react';

const HealthHero = () => {
  return (
    <section className="bg-gradient-to-r from-green-400 to-blue-500 text-white py-20 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl font-bold mb-6">Transforma tu relación con la comida</h2>
        <p className="text-xl mb-8">
          Desde planes especializados hasta menús semanales personalizados, 
          tenemos todo lo que necesitas para una alimentación saludable
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <button 
            onClick={() => document.getElementById('menu-planner').scrollIntoView({behavior: 'smooth'})}
            className="bg-white text-green-700 hover:bg-gray-100 font-bold py-3 px-6 rounded-lg transition"
          >
            Planificar mi menú
          </button>
          <button className="bg-transparent border-2 border-white hover:bg-white hover:text-green-700 font-bold py-3 px-6 rounded-lg transition">
            Necesito ayuda
          </button>
        </div>
      </div>
    </section>
  );
};

export default HealthHero;