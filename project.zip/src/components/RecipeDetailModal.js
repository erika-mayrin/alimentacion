import React from 'react';

const RecipeDetailModal = ({ recipe, onClose }) => {
  if (!recipe) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-2xl font-bold">{recipe.name}</h2>
            <button 
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              ✕
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-green-100 p-4 rounded-lg">
              <h3 className="font-bold mb-2">Información</h3>
              <p>Tiempo: {recipe.time}</p>
              <p>Dificultad: {recipe.difficulty}</p>
              <p>Calorías: {recipe.calories} kcal</p>
            </div>
            
            <div className="bg-yellow-100 p-4 rounded-lg md:col-span-2">
              <h3 className="font-bold mb-2">Ingredientes</h3>
              <ul className="list-disc pl-5">
                {recipe.ingredients.map((ingredient, index) => (
                  <li key={index}>{ingredient}</li>
                ))}
              </ul>
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="font-bold mb-2">Preparación</h3>
            <ol className="list-decimal pl-5 space-y-2">
              {recipe.steps.map((step, index) => (
                <li key={index}>{step}</li>
              ))}
            </ol>
          </div>
          
          <div className="bg-blue-100 p-4 rounded-lg">
            <h3 className="font-bold mb-2">Notas nutricionales</h3>
            <p>{recipe.nutritionNotes}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecipeDetailModal;