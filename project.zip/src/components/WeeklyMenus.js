import React, { useState } from 'react';
import WeeklyMenuDetail from './WeeklyMenuDetail';

const WeeklyMenus = () => {
  const [selectedMenu, setSelectedMenu] = useState(null);

  const weeklyOptions = [
    {
      id: 1,
      title: "Mediterráneo",
      description: "Basado en la dieta mediterránea, rico en pescado, aceite de oliva y vegetales frescos",
      calories: "1800-2200 kcal/día",
      proteins: "70-90g",
      carbs: "180-220g",
      fats: "50-70g",
      recommendations: [
        "Beber 2L de agua diarios",
        "Consumir aceite de oliva virgen extra",
        "Priorizar pescados sobre carnes rojas",
        "30 minutos de actividad física diaria"
      ],
      days: [
        {
          name: "Lunes",
          breakfast: "Tostadas integrales con tomate y aceite + café",
          lunch: "Ensalada griega con atún + pan integral",
          dinner: "Merluza al horno con patatas y espárragos"
        },
        {
          name: "Martes",
          breakfast: "Yogur con granola y frutas + té verde",
          lunch: "Pasta integral con pesto y tomates cherry",
          dinner: "Tortilla de espinacas con ensalada"
        },
        {
          name: "Miércoles",
          breakfast: "Smoothie de plátano y avena + nueces",
          lunch: "Lentejas con verduras + arroz integral",
          dinner: "Salmón a la plancha con quinoa"
        },
        {
          name: "Jueves",
          breakfast: "Tostadas con aguacate y huevo pochado",
          lunch: "Ensalada de garbanzos con pimientos",
          dinner: "Pollo al curry con arroz basmati"
        },
        {
          name: "Viernes",
          breakfast: "Avena con leche de almendras y canela",
          lunch: "Sardinas a la plancha con ensalada",
          dinner: "Crema de calabaza con semillas"
        },
        {
          name: "Sábado",
          breakfast: "Revuelto de champiñones con pan integral",
          lunch: "Paella de mariscos",
          dinner: "Ensalada caprese con mozzarella"
        },
        {
          name: "Domingo",
          breakfast: "Tortitas de avena con miel",
          lunch: "Pechuga de pollo con puré de calabaza",
          dinner: "Sopa minestrone con pan integral"
        }
      ]
    },
    {
      id: 2,
      title: "Vegetariano",
      description: "Planes sin carne con proteínas vegetales balanceadas y variedad de nutrientes",
      calories: "1600-2000 kcal/día",
      proteins: "60-80g",
      carbs: "200-240g",
      fats: "40-60g",
      recommendations: [
        "Incluir variedad de legumbres",
        "Combinar cereales con legumbres",
        "Consumir frutos secos diariamente",
        "Suplementar con B12 si es necesario"
      ],
      days: [
        {
          name: "Lunes",
          breakfast: "Batido de proteína vegetal con plátano",
          lunch: "Buddha bowl con quinoa y garbanzos",
          dinner: "Curry de lentejas con arroz"
        },
        {
          name: "Martes",
          breakfast: "Tostadas con hummus y tomate",
          lunch: "Ensalada de espinacas con tofu",
          dinner: "Lasagna vegetariana"
        },
        {
          name: "Miércoles",
          breakfast: "Porridge de avena con frutos rojos",
          lunch: "Hamburguesa de lentejas con ensalada",
          dinner: "Crema de calabacín con semillas"
        },
        {
          name: "Jueves",
          breakfast: "Yogur vegetal con granola",
          lunch: "Falafel con pan de pita",
          dinner: "Risotto de champiñones"
        },
        {
          name: "Viernes",
          breakfast: "Smoothie verde con espinacas",
          lunch: "Tacos de frijoles con guacamole",
          dinner: "Sopa miso con tofu"
        },
        {
          name: "Sábado",
          breakfast: "Tortitas de harina de garbanzo",
          lunch: "Pizza vegetariana integral",
          dinner: "Ensalada de quinoa y aguacate"
        },
        {
          name: "Domingo",
          breakfast: "Chía pudding con frutas",
          lunch: "Estofado de seitán con verduras",
          dinner: "Wok de verduras con tofu"
        }
      ]
    },
    {
      id: 3,
      title: "Bajo en carbohidratos",
      description: "Enfocado en controlar la ingesta de carbohidratos y aumentar grasas saludables",
      calories: "1500-1800 kcal/día",
      proteins: "90-110g",
      carbs: "50-80g",
      fats: "100-120g",
      recommendations: [
        "Priorizar grasas saludables",
        "Consumir vegetales bajos en carbohidratos",
        "Mantener buena hidratación",
        "Monitorizar electrolitos"
      ],
      days: [
        {
          name: "Lunes",
          breakfast: "Revuelto de huevos con aguacate",
          lunch: "Pechuga de pollo con brócoli",
          dinner: "Salmón con espárragos"
        },
        {
          name: "Martes",
          breakfast: "Yogur griego con nueces",
          lunch: "Ensalada César sin croutones",
          dinner: "Carne asada con coliflor"
        },
        {
          name: "Miércoles",
          breakfast: "Tortilla de espinacas",
          lunch: "Atún con ensalada verde",
          dinner: "Costillas de cerdo con champiñones"
        },
        {
          name: "Jueves",
          breakfast: "Café con crema + frutos secos",
          lunch: "Hamburguesa sin pan con queso",
          dinner: "Pollo al curry con coliflor"
        },
        {
          name: "Viernes",
          breakfast: "Smoothie keto con mantequilla de almendras",
          lunch: "Filete de ternera con espinacas",
          dinner: "Camarones al ajillo"
        },
        {
          name: "Sábado",
          breakfast: "Pancakes de almendra",
          lunch: "Ensalada de salmón y aguacate",
          dinner: "Pollo relleno de queso de cabra"
        },
        {
          name: "Domingo",
          breakfast: "Huevos benedictinos sin pan",
          lunch: "Brochetas de carne con pimientos",
          dinner: "Sopa de mariscos"
        }
      ]
    }
  ];

  return (
    <>
      <section className="py-16 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold mb-8">Menús Semanales</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {weeklyOptions.map(option => (
              <div key={option.id} className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition cursor-pointer" onClick={() => setSelectedMenu(option)}>
                <div className="h-40 bg-blue-100 rounded-lg mb-4 flex items-center justify-center">
                  <span className="text-4xl">📅</span>
                </div>
                <h3 className="text-xl font-bold mb-2">{option.title}</h3>
                <p className="text-gray-600 mb-4">{option.description}</p>
                <div className="text-sm text-gray-500 mb-4">
                  <span>Calorías: {option.calories}</span>
                </div>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition">
                  Ver menú completo
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {selectedMenu && (
        <WeeklyMenuDetail 
          menu={selectedMenu} 
          onClose={() => setSelectedMenu(null)} 
        />
      )}
    </>
  );
};

export default WeeklyMenus;

// DONE