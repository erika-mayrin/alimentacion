import React from 'react';

const WeeklyMenuDetail = ({ menu, onClose }) => {
  if (!menu) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold">{menu.title}</h2>
            <button 
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              ✕
            </button>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-4">Descripción</h3>
            <p className="text-gray-600">{menu.description}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Información Nutricional</h3>
              <p>Calorías diarias: {menu.calories}</p>
              <p>Proteínas: {menu.proteins}g</p>
              <p>Carbohidratos: {menu.carbs}g</p>
              <p>Grasas: {menu.fats}g</p>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Recomendaciones</h3>
              <ul className="list-disc pl-5 space-y-1">
                {menu.recommendations.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-4">Menú Semanal</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border border-gray-200">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="py-3 px-4 text-left">Día</th>
                    <th className="py-3 px-4 text-left">Desayuno</th>
                    <th className="py-3 px-4 text-left">Almuerzo</th>
                    <th className="py-3 px-4 text-left">Cena</th>
                  </tr>
                </thead>
                <tbody>
                  {menu.days.map((day, index) => (
                    <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium">{day.name}</td>
                      <td className="py-3 px-4">{day.breakfast}</td>
                      <td className="py-3 px-4">{day.lunch}</td>
                      <td className="py-3 px-4">{day.dinner}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex justify-center gap-4">
            <button 
              onClick={() => window.print()}
              className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-lg transition"
            >
              Imprimir Menú
            </button>
            <button className="bg-green-600 hover:bg-green-700 text-white py-2 px-6 rounded-lg transition">
              Descargar PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeeklyMenuDetail;