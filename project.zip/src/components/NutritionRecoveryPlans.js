import React, { useState } from 'react';
import RecoveryPlanDetail from './RecoveryPlanDetail';

const NutritionRecoveryPlans = () => {
  const [selectedPlan, setSelectedPlan] = useState(null);

  const recoveryPlans = [
    {
      id: 1,
      title: "Plan de Reintroducción Alimentaria",
      description: "Programa gradual para restablecer una relación saludable con la comida después de trastornos alimenticios o periodos de restricción severa.",
      duration: "8 semanas",
      mealsPerDay: 5,
      calories: "1800-2400 kcal/día",
      goal: "Normalizar patrones alimentarios y recuperar peso saludable",
      recommendations: [
        "Seguir horarios regulares de comidas",
        "Evitar pesarse frecuentemente",
        "Practicar mindful eating",
        "Mantener un diario alimentario emocional"
      ],
      structure: [
        {
          phase: "Fase 1: Estabilización (2 semanas)",
          description: "Enfoque en regularizar horarios y cantidades mínimas",
          details: [
            "3 comidas principales + 2 snacks",
            "Grupos alimentarios básicos en cada comida",
            "Tamaños de porción controlados"
          ]
        },
        {
          phase: "Fase 2: Diversificación (3 semanas)",
          description: "Introducción progresiva de alimentos temidos",
          details: [
            "Añadir 1-2 alimentos nuevos por semana",
            "Exposición gradual a situaciones alimentarias",
            "Trabajar en distorsiones cognitivas"
          ]
        },
        {
          phase: "Fase 3: Consolidación (3 semanas)",
          description: "Mantenimiento y prevención de recaídas",
          details: [
            "Flexibilidad en elecciones alimentarias",
            "Manejo de situaciones sociales",
            "Estrategias de afrontamiento"
          ]
        }
      ],
      recommendedFoods: [
        "Avena", "Aguacate", "Salmón", "Huevos", 
        "Quinoa", "Batata", "Nueces", "Yogur griego",
        "Pollo", "Garbanzos", "Espinacas", "Plátano"
      ]
    },
    {
      id: 2,
      title: "Equilibrio Nutricional",
      description: "Plan para corregir deficiencias nutricionales y restablecer niveles óptimos de vitaminas y minerales esenciales.",
      duration: "12 semanas",
      mealsPerDay: 4,
      calories: "2000-2500 kcal/día",
      goal: "Corregir deficiencias y optimizar estado nutricional",
      recommendations: [
        "Suplementación según necesidades",
        "Monitorización de parámetros bioquímicos",
        "Combinación adecuada de nutrientes",
        "Cocción que preserve nutrientes"
      ],
      structure: [
        {
          phase: "Fase 1: Evaluación (2 semanas)",
          description: "Identificación de carencias específicas",
          details: [
            "Análisis de sangre completo",
            "Evaluación de ingesta actual",
            "Identificación de factores de malabsorción"
          ]
        },
        {
          phase: "Fase 2: Corrección (6 semanas)",
          description: "Enfoque en nutrientes deficitarios",
          details: [
            "Alimentos ricos en nutrientes clave",
            "Técnicas de preparación que maximizan absorción",
            "Suplementación dirigida"
          ]
        },
        {
          phase: "Fase 3: Mantenimiento (4 semanas)",
          description: "Consolidación de hábitos alimentarios",
          details: [
            "Dieta variada y equilibrada",
            "Estrategias para mantener niveles óptimos",
            "Prevención de recaídas"
          ]
        }
      ],
      recommendedFoods: [
        "Hígado", "Espinacas", "Almendras", "Sardinas",
        "Lentejas", "Pimiento rojo", "Ostras", "Huevos",
        "Kiwi", "Semillas de girasol", "Brócoli", "Carne roja"
      ]
    },
    {
      id: 3,
      title: "Recuperación de Energía",
      description: "Programa para aumentar la ingesta calórica de forma saludable en casos de bajo peso o fatiga crónica nutricional.",
      duration: "6 semanas",
      mealsPerDay: 6,
      calories: "2500-3000 kcal/día",
      goal: "Ganancia de peso saludable y recuperación energética",
      recommendations: [
        "Comer cada 2-3 horas",
        "Priorizar densidad calórica saludable",
        "Incluir snacks nutritivos",
        "Monitorizar progreso semanal"
      ],
      structure: [
        {
          phase: "Fase 1: Adaptación (1 semana)",
          description: "Aumento gradual de ingesta",
          details: [
            "Añadir 1 snack extra al día",
            "Alimentos familiares y bien tolerados",
            "Enfoque en comidas pequeñas y frecuentes"
          ]
        },
        {
          phase: "Fase 2: Consolidación (3 semanas)",
          description: "Aumento calórico significativo",
          details: [
            "6 comidas al día",
            "Inclusión de alimentos calóricos saludables",
            "Técnicas para aumentar densidad nutricional"
          ]
        },
        {
          phase: "Fase 3: Mantenimiento (2 semanas)",
          description: "Estabilización del nuevo patrón",
          details: [
            "Ajuste según respuesta individual",
            "Estrategias para mantener ingesta",
            "Prevención de recaídas"
          ]
        }
      ],
      recommendedFoods: [
        "Aceite de oliva", "Aguacate", "Frutos secos", "Mantequilla de maní",
        "Quinoa", "Salmón", "Huevos", "Batata",
        "Granola", "Aceitunas", "Queso", "Dátiles"
      ]
    }
  ];

  return (
    <>
      <section className="py-16 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold mb-8">Planes de Recuperación Nutricional</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {recoveryPlans.map(plan => (
              <div key={plan.id} className="bg-gray-50 p-6 rounded-xl border border-gray-200 hover:shadow-md transition cursor-pointer" onClick={() => setSelectedPlan(plan)}>
                <div className="h-40 bg-red-100 rounded-lg mb-4 flex items-center justify-center">
                  <span className="text-4xl">❤️</span>
                </div>
                <h3 className="text-xl font-bold mb-2">{plan.title}</h3>
                <p className="text-gray-600 mb-4">{plan.description}</p>
                <div className="flex justify-between text-sm text-gray-500">
                  <span>Duración: {plan.duration}</span>
                  <span>Comidas/día: {plan.mealsPerDay}</span>
                </div>
                <button className="mt-4 w-full bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg transition">
                  Ver plan completo
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {selectedPlan && (
        <RecoveryPlanDetail 
          plan={selectedPlan} 
          onClose={() => setSelectedPlan(null)} 
        />
      )}
    </>
  );
};

export default NutritionRecoveryPlans;

// DONE