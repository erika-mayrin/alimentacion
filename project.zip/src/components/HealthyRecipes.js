import React, { useState } from 'react';
import RecipeDetailModal from './RecipeDetailModal';

const HealthyRecipes = () => {
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  
  const recipes = [
    {
      id: 1,
      name: "Bowl de quinoa y aguacate",
      time: "25 min",
      difficulty: "Fácil",
      calories: 420,
      ingredients: [
        "1 taza de quinoa cocida",
        "1/2 aguacate",
        "1/2 taza de garbanzos cocidos",
        "1/4 de pimiento rojo",
        "1 cucharada de semillas de girasol",
        "1 cucharada de aceite de oliva",
        "Jugo de 1/2 limón",
        "Sal y pimienta al gusto"
      ],
      steps: [
        "Enjuagar bien la quinoa bajo agua fría.",
        "Cocinar la quinoa según instrucciones del paquete.",
        "Picar el aguacate y el pimiento en cubos pequeños.",
        "Mezclar todos los ingredientes en un bowl.",
        "Aliñar con aceite de oliva, jugo de limón, sal y pimienta.",
        "Decorar con semillas de girasol y servir."
      ],
      nutritionNotes: "Alto contenido en fibra y ácidos grasos saludables. Buena fuente de proteína vegetal."
    },
    {
      id: 2,
      name: "Salmón al horno con espárragos",
      time: "35 min",
      difficulty: "Media",
      calories: 380,
      ingredients: [
        "1 filete de salmón (200g)",
        "10 espárragos verdes",
        "1 cucharada de aceite de oliva",
        "1 diente de ajo picado",
        "1/2 limón en rodajas",
        "Eneldo fresco",
        "Sal y pimienta al gusto"
      ],
      steps: [
        "Precalentar el horno a 190°C.",
        "Lavar y cortar los espárragos, quitando los extremos duros.",
        "En un recipiente para horno, colocar el salmón y los espárragos.",
        "Aliñar con aceite de oliva, ajo picado, sal y pimienta.",
        "Colocar las rodajas de limón sobre el salmón.",
        "Hornear por 20-25 minutos hasta que el salmón esté cocido.",
        "Decorar con eneldo fresco antes de servir."
      ],
      nutritionNotes: "Excelente fuente de omega-3 y proteínas de alta calidad. Los espárragos aportan fibra y folatos."
    },
    {
      id: 3,
      name: "Ensalada de garbanzos y espinacas",
      time: "15 min",
      difficulty: "Fácil",
      calories: 290,
      ingredients: [
        "1 taza de garbanzos cocidos",
        "2 tazas de espinacas frescas",
        "1/4 de cebolla morada",
        "8 tomates cherry",
        "1 cucharada de aceite de oliva",
        "1 cucharadita de vinagre balsámico",
        "1 cucharadita de mostaza",
        "Sal y pimienta al gusto"
      ],
      steps: [
        "Lavar bien las espinacas y escurrir.",
        "Cortar la cebolla en juliana fina y los tomates por la mitad.",
        "En un bol grande, mezclar los garbanzos con las espinacas, cebolla y tomates.",
        "Preparar el aliño mezclando aceite, vinagre, mostaza, sal y pimienta.",
        "Verter el aliño sobre la ensalada y mezclar bien.",
        "Servir inmediatamente."
      ],
      nutritionNotes: "Rica en hierro y proteína vegetal. Bajo índice glucémico y alto contenido en fibra."
    }
  ];

  return (
    <>
      <section className="py-16 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold mb-8">Recetas Saludables</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {recipes.map(recipe => (
              <div key={recipe.id} className="bg-gray-50 p-6 rounded-xl hover:shadow-md transition cursor-pointer" onClick={() => setSelectedRecipe(recipe)}>
                <div className="h-40 bg-green-100 rounded-lg mb-4 flex items-center justify-center">
                  <span className="text-4xl">🍴</span>
                </div>
                <h3 className="text-xl font-bold mb-2">{recipe.name}</h3>
                <div className="flex justify-between text-sm text-gray-500 mb-4">
                  <span>Tiempo: {recipe.time}</span>
                  <span>Dificultad: {recipe.difficulty}</span>
                </div>
                <div className="text-green-600 font-medium mb-4">
                  {recipe.calories} kcal
                </div>
                <button className="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg transition">
                  Ver receta
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {selectedRecipe && (
        <RecipeDetailModal 
          recipe={selectedRecipe} 
          onClose={() => setSelectedRecipe(null)} 
        />
      )}
    </>
  );
};

export default HealthyRecipes;

// DONE