import React, { useState } from 'react';

const MenuPlanner = () => {
  const [activeTab, setActiveTab] = useState('breakfast');
  const [selectedDays, setSelectedDays] = useState([]);
  const [menuPlan, setMenuPlan] = useState({
    breakfast: {},
    lunch: {},
    dinner: {},
    snacks: {}
  });

  const days = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
  const mealOptions = {
    breakfast: [
      'Yogur con granola y frutas',
      'Tostadas integrales con aguacate',
      'Huevos revueltos con espinacas',
      'Smoothie de proteína',
      'Avena con frutos secos'
    ],
    lunch: [
      'Ensalada César con pollo',
      'Quinoa con vegetales asados',
      'Pasta integral con pesto',
      'Wrap de garbanzos y vegetales',
      'Salmón con arroz integral'
    ],
    dinner: [
      'Crema de calabaza',
      'Tortilla de espinacas',
      'Pechuga a la plancha con puré',
      'Sopa minestrone',
      'Buddha bowl vegetariano'
    ],
    snacks: [
      'Fruta con almendras',
      'Yogur griego',
      'Bastones de zanahoria con hummus',
      'Galletas integrales con queso',
      'Batido verde'
    ]
  };

  const handleDaySelection = (day) => {
    setSelectedDays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day) 
        : [...prev, day]
    );
  };

  const handleMealSelection = (meal, option) => {
    const newPlan = {...menuPlan};
    selectedDays.forEach(day => {
      if (!newPlan[meal][day]) {
        newPlan[meal][day] = [];
      }
      newPlan[meal][day] = option;
    });
    setMenuPlan(newPlan);
  };

  const savePlan = () => {
    localStorage.setItem('menuPlan', JSON.stringify(menuPlan));
    alert('¡Plan guardado con éxito!');
  };

  return (
    <section className="py-16 px-6 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-8">Planificador de Menú Semanal</h2>
        
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h3 className="text-xl font-semibold mb-4">Selecciona los días</h3>
          <div className="flex flex-wrap gap-2 mb-6">
            {days.map(day => (
              <button
                key={day}
                onClick={() => handleDaySelection(day)}
                className={`px-4 py-2 rounded-lg ${selectedDays.includes(day) ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-700'}`}
              >
                {day}
              </button>
            ))}
          </div>

          <div className="border-b border-gray-200 mb-6">
            <nav className="flex space-x-4">
              {['breakfast', 'lunch', 'dinner', 'snacks'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 font-medium ${activeTab === tab ? 'border-b-2 border-green-600 text-green-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  {tab === 'breakfast' && 'Desayuno'}
                  {tab === 'lunch' && 'Almuerzo'}
                  {tab === 'dinner' && 'Cena'}
                  {tab === 'snacks' && 'Snacks'}
                </button>
              ))}
            </nav>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
            {mealOptions[activeTab].map(option => (
              <div 
                key={option}
                onClick={() => handleMealSelection(activeTab, option)}
                className="border border-gray-200 rounded-lg p-4 hover:bg-green-50 hover:border-green-200 cursor-pointer"
              >
                <h4 className="font-medium">{option}</h4>
              </div>
            ))}
          </div>

          <button 
            onClick={savePlan}
            disabled={selectedDays.length === 0}
            className={`px-6 py-3 rounded-lg font-medium ${selectedDays.length === 0 ? 'bg-gray-300 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700 text-white'}`}
          >
            Guardar Plan
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-xl font-semibold mb-6">Tu Plan Semanal</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full border border-gray-200">
              <thead className="bg-gray-100">
                <tr>
                  <th className="py-3 px-4 text-left">Día</th>
                  <th className="py-3 px-4 text-left">Desayuno</th>
                  <th className="py-3 px-4 text-left">Almuerzo</th>
                  <th className="py-3 px-4 text-left">Cena</th>
                  <th className="py-3 px-4 text-left">Snacks</th>
                </tr>
              </thead>
              <tbody>
                {days.map(day => (
                  <tr key={day} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium">{day}</td>
                    <td className="py-3 px-4">{menuPlan.breakfast[day] || '-'}</td>
                    <td className="py-3 px-4">{menuPlan.lunch[day] || '-'}</td>
                    <td className="py-3 px-4">{menuPlan.dinner[day] || '-'}</td>
                    <td className="py-3 px-4">{menuPlan.snacks[day] || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MenuPlanner;