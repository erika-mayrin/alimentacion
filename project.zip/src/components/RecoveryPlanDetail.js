import React from 'react';

const RecoveryPlanDetail = ({ plan, onClose }) => {
  if (!plan) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold">{plan.title}</h2>
            <button 
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              ✕
            </button>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-4">Descripción</h3>
            <p className="text-gray-600">{plan.description}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-red-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Información del Plan</h3>
              <p>Duración: {plan.duration}</p>
              <p>Comidas por día: {plan.mealsPerDay}</p>
              <p>Calorías diarias: {plan.calories}</p>
              <p>Objetivo: {plan.goal}</p>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Recomendaciones</h3>
              <ul className="list-disc pl-5 space-y-1">
                {plan.recommendations.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-4">Estructura del Plan</h3>
            <div className="space-y-4">
              {plan.structure.map((phase, index) => (
                <div key={index} className="border-l-4 border-red-400 pl-4">
                  <h4 className="font-semibold text-lg">{phase.phase}</h4>
                  <p className="text-gray-600">{phase.description}</p>
                  <ul className="list-disc pl-5 mt-2">
                    {phase.details.map((detail, i) => (
                      <li key={i}>{detail}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-green-50 p-4 rounded-lg mb-6">
            <h3 className="font-semibold mb-3">Alimentos Recomendados</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {plan.recommendedFoods.map((food, index) => (
                <span key={index} className="bg-white px-3 py-1 rounded-full text-sm">
                  {food}
                </span>
              ))}
            </div>
          </div>

          <div className="flex justify-center gap-4">
            <button 
              onClick={() => window.print()}
              className="bg-red-600 hover:bg-red-700 text-white py-2 px-6 rounded-lg transition"
            >
              Imprimir Plan
            </button>
            <button className="bg-green-600 hover:bg-green-700 text-white py-2 px-6 rounded-lg transition">
              Descargar Guía
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecoveryPlanDetail;